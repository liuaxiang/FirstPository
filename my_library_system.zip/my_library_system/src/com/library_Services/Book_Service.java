package com.library_Services;

import java.sql.Date;
import java.util.ArrayList;

import com.library_Dao.Book_Dao;
import com.library_Dao.Reader_Dao;
import com.library_entity.Book;
import com.library_entity.Fin_informattion;
import com.library_entity.History;

public class Book_Service implements Book_ServiceInfo{
	//查询书籍
	public ArrayList<Book> SelectBookssByUbook_name(String book_name) {
		Book_Dao book_dao=new Book_Dao();
		ArrayList<Book> As=book_dao.SelectBoods(book_name);
			return As;
	   }

	//借书信息插入
	@Override
	public boolean LentBookSevice(int reader_id, int book_id) {
		boolean temp=false;
		Reader_Dao readerdao=new Reader_Dao();
		int row=readerdao.InsertIntoLentBook(reader_id, book_id);
		if(row>0) {
				temp=true;
			}
		return temp;
	}
//更新书籍数量
	@Override
	public boolean ShowLentBook(int book_id) {
		boolean temp=false;
		Book_Dao bookdao=new Book_Dao();
		int row=bookdao.UpdateBookSum(book_id);
		if(row>0) {
				temp=true;
			}
		return temp;
	}
//显示借书信息
	@Override
	public ArrayList<Book> ShowLentBooks(int reader_id) {
		Book_Dao book_dao=new Book_Dao();
		ArrayList<Book> As=book_dao.ShowLentBoods(reader_id);
		return As;
	}
	//将信息插入history表
	@Override
	public boolean InsertHistory(int reader_id,int book_id,int lent_id,Date lent_time) {
		boolean temp=false;
		Book_Dao bookdao=new Book_Dao();
		int row=bookdao.Insert_History(reader_id,book_id,lent_id,lent_time);
		if(row>0) {
				temp=true;
			}
		return temp;
	}
	//将信息插入fine表
	@Override
	public boolean InsertFine(int reader_id,int book_id,Date lent_time) {
		boolean temp=false;
		Book_Dao bookdao=new Book_Dao();
		int row=bookdao.Insert_Fine(reader_id,book_id,lent_time);
		if(row>0) {
				temp=true;
			}
		return temp;
	}
	//显示历史纪录信息
	@Override
	public ArrayList<Book> ShowRecord() {
		Book_Dao book_dao=new Book_Dao();
		ArrayList<Book> As=book_dao.ShowRecord();
		return As;
	}
//还书
	@Override
	public boolean ReturnBook(int book_id) {
		boolean temp=false;
		Book_Dao bookdao=new Book_Dao();
		int row=bookdao.DelectLentBook(book_id);
		if(row>0) {
				temp=true;
			}
		return temp;
	}
//还书后书籍数量加一
	@Override
	public boolean UpadeBookSum(int book_id) {
		boolean temp=false;
		Book_Dao bookdao=new Book_Dao();
		int row=bookdao.UpdateBookSum2(book_id);
		if(row>0) {
			temp=true;
		}
		return temp;
	}
//还书后插入还书时间
	@Override
	public boolean InsrtReturnTime(int book_id) {
		boolean temp=false;
		Book_Dao bookdao=new Book_Dao();
		int row=bookdao.InserReturnTime(book_id);
		if(row>0) {
			temp=true;
		}
		return temp;
	}
	//显示历史纪录信息
	@Override
	public ArrayList<History> SelectHistory(int reader_id) {
		Book_Dao book_dao=new Book_Dao();
		ArrayList<History> As=book_dao.SelectHistory(reader_id);
		return As;
	}
	//查询over_time
	@Override
	public ArrayList<Fin_informattion> Select_OverTime(int reader_id) {
		Book_Dao book_dao=new Book_Dao();
		ArrayList<Fin_informattion> over_time=book_dao.Select_OverTime(reader_id);
		return over_time;
	}
	//将逾期时间、罚款信息插入fine表
	@Override
	public boolean InsertIntoFine(long over_day, float fine, int reader_id) {
		boolean temp=false;
		Book_Dao bookdao=new Book_Dao();
		int row=bookdao.InserIntoFine(over_day, fine, reader_id);
		if(row>0) {
				temp=true;
			}
		return temp;
	}
	//显示罚款信息
	@Override
	public ArrayList<Fin_informattion> ShowFine(int reader_id) {
		Book_Dao book_dao=new Book_Dao();
		ArrayList<Fin_informattion> As=book_dao.ShowFine(reader_id);
		return As;
	}
	//查询是否存在罚款
	@Override
	public boolean SelectFine() {
		boolean temp=false;
		Book_Dao bookdao=new Book_Dao();
		int row=bookdao.SelectFine();
		if(row>0) {
				temp=true;
			}
		return temp;
	}

	//提交罚款
	@Override
	public boolean DeleteFine(int fine_id) {
		boolean temp=false;
		Book_Dao bookdao=new Book_Dao();
		int row=bookdao.DeleteFine(fine_id);
		if(row>0) {
				temp=true;
			}
		return temp;
	}
	//还书后删除多余罚款信息
	@Override
	public boolean DeleteFineByReader_idAndBook_id(int reader_id, int book_id) {
		boolean temp=false;
		Book_Dao bookdao=new Book_Dao();
		int row=bookdao.DeleteOtherFine(reader_id, book_id);
		if(row>0) {
				temp=true;
			}
		return temp;
	}  
}
