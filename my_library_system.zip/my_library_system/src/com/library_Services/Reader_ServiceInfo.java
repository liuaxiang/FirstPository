package com.library_Services;

import com.library_entity.Reader;

public interface Reader_ServiceInfo {
	//读者登录
	Reader ReaderLogin(String readername,String password);
	//读者注册
	boolean RegisterSevice(Reader reader);

	
}
