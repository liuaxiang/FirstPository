package com.library_Services;

import java.util.ArrayList;

import com.library_entity.Admin;
import com.library_entity.Book;
import com.library_entity.Reader;

public interface Admin_ServicesInfo {
	//管理员登录
	Admin AdminLogin(String admain_name,String password);
	//添加书籍
	boolean AddBooksSevice(Book book);
	//更新书籍信息
	boolean UpdateBooksSevice(Book book);
	//显示所修改书的信息
	public ArrayList<Book> ShowBook(int book_id);
	//删除书籍
	boolean DeleteBook(int book_id);
}
