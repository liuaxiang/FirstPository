package com.library_Services;

import java.sql.Date;
import java.util.ArrayList;

import com.library_entity.Book;
import com.library_entity.Fin_informattion;
import com.library_entity.History;

public interface Book_ServiceInfo {
	//书籍查询
	public ArrayList<Book> SelectBookssByUbook_name(String book_name);
	//借书信息插入判断
	boolean LentBookSevice(int reader_id,int book_id );
	//书籍数量减一
	boolean ShowLentBook(int book_id );
	//显示借书书信息
	public ArrayList<Book> ShowLentBooks(int reader_id);
	//将reader_id,bookid,lent_id,lent_time插入history表
	boolean InsertHistory(int reader_id,int book_id,int lent_id,Date lent_time);
	//将reader_id,bookid,lent_time插入fine表
	boolean InsertFine(int reader_id,int book_id,Date lent_time);
	//显示历史纪录信息
	public ArrayList<Book> ShowRecord();
	//还书
	boolean ReturnBook(int book_id );
	//书籍数量加一
	boolean UpadeBookSum(int book_id );
	//还书后插入还书时间
	boolean InsrtReturnTime(int book_id);
	//显示借书历史信息
	public ArrayList<History> SelectHistory(int reader_id);
	//查询over_time
	public ArrayList<Fin_informattion> Select_OverTime(int reader_id);
	//将逾期时间、罚款信息插入fine表
	boolean InsertIntoFine(long over_day,float fine,int reader_id);
	//显示罚款信息
	public ArrayList<Fin_informattion> ShowFine(int reader_id);
	//查询是否存在罚款
	boolean SelectFine();
	//提交罚款
	boolean DeleteFine(int fine_id );
	//还书后删除多余罚款信息
	boolean DeleteFineByReader_idAndBook_id(int reader_id,int book_id );
}
