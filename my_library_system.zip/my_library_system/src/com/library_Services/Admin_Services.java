package com.library_Services;

import java.util.ArrayList;

import com.library_Dao.Admin_Dao;
import com.library_Dao.Book_Dao;
import com.library_Dao.Reader_Dao;
import com.library_entity.Admin;
import com.library_entity.Book;
import com.library_entity.Reader;

public class Admin_Services implements Admin_ServicesInfo{

	@Override
	public Admin AdminLogin(String admain_name, String password) {
		Admin_Dao admin_dao=new Admin_Dao();
		Admin admin=admin_dao.queryAdminByAdminNamePassword(admain_name, password);
		return admin;
	}
	//添加书籍
	@Override
	public boolean AddBooksSevice(Book book) {
		boolean temp=false;
		Admin_Dao admin_dao=new Admin_Dao();
		int row=admin_dao.AddBook(book);
		if(row>0) {
				temp=true;
			}
		return temp;
	}
	//更新书籍信息
	@Override
	public boolean UpdateBooksSevice(Book book) {
		boolean temp=false;
		Admin_Dao admin_dao=new Admin_Dao();
		int row=admin_dao.UpdateBook(book);
		if(row>0) {
				temp=true;
			}
		return temp;
	}
	//显示所修改书的信息
	@Override
	public ArrayList<Book> ShowBook(int book_id) {
		Admin_Dao admin_dao=new Admin_Dao();
		ArrayList<Book> As=admin_dao.ShowBook(book_id);
			return As;
	}
	//删除书籍
	@Override
	public boolean DeleteBook(int book_id) {
		boolean temp=false;
		Admin_Dao admin_dao=new Admin_Dao();
		int row=admin_dao.DeleteBook(book_id);
		if(row>0) {
				temp=true;
			}
		return temp;
	}

}
