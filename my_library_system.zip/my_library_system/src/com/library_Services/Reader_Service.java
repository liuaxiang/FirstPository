package com.library_Services;

import com.library_Dao.Reader_Dao;
import com.library_entity.Reader;

public class Reader_Service implements Reader_ServiceInfo{
	private Reader_Dao reader_dao=new Reader_Dao();
    //读者登录验证
	@Override
	public Reader ReaderLogin(String readername, String password) {
		Reader reader=reader_dao.queryReaderByReaderNamePassword(readername, password);
		return reader;
		
	}
	 //读者信息注册
	@Override
	public boolean RegisterSevice(Reader reader) {
		boolean temp=false;
		Reader_Dao readerdao=new Reader_Dao();
		int row=readerdao.AddReader(reader);
		if(row>0) {
				temp=true;
			}
		return temp;
	}

}
