package com.library_Control;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library_Services.Book_Service;
import com.library_entity.Book;

/**
 * Servlet implementation class Select_Books
 */
@WebServlet("/Select_Books")
public class Select_Books extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String book_name=request.getParameter("book_name");
		System.out.println("book_name:"+book_name);
		
//		response.setContentType("text/html;charset=utf-8");
//		PrintWriter pw=null;
//		pw = response.getWriter();
		//查询书籍
		Book_Service book_service=new Book_Service();
		ArrayList<Book> select_books2=new ArrayList<> ();
		select_books2=book_service.SelectBookssByUbook_name(book_name);
		//把书籍信息送往前端
		request.setAttribute("Select_books",  select_books2);
		request.getRequestDispatcher("edit.jsp").forward(request, response);
	}
       
   
}
