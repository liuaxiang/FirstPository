package com.library_Control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Modify_Book
 */
@WebServlet("/Modify_Book")
public class Modify_Book extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		//获取注册页面信息
		String book_name=request.getParameter("book_name");
		String book_writer=request.getParameter("book_writer");
		int category_id=Integer.parseInt(request.getParameter("category_id"));
		int book_sum=Integer.parseInt(request.getParameter("book_sum"));
		String location=request.getParameter("location");
		//将信息上传数据库
		
	}



}
