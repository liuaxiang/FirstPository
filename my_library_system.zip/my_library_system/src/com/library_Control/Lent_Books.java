package com.library_Control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.ArrayList;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.library_Dao.Book_Dao;
import com.library_Services.Book_Service;
import com.library_entity.Lent_information;
import com.library_entity.Reader;

/**
 * Servlet implementation class Lent_Books
 */
@WebServlet("/Lent_Books")
public class Lent_Books extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");
		
		//获取book_name和book_id
		String book_name = req.getParameter("BookName");
		String book_writer = req.getParameter("BookWriter");
		int book_id = Integer.parseInt(req.getParameter("BookId"));
		System.out.println("book_name:"+book_name);
		System.out.println("book_writer:"+book_writer);
		System.out.println("book_id:"+book_id);				
		//从session中获取reader_id
		HttpSession session=req.getSession();
		Reader reader=(Reader) session.getAttribute("reader");
		int reader_id=reader.getReader_id();		
		System.out.println("reader_id:"+reader_id);		
		//查询是否存在罚款
		Book_Service book_service=new Book_Service();		
		boolean temp=book_service.SelectFine();
		resp.setContentType("text/html;charset=utf-8");
		PrintWriter pw=resp.getWriter();
	
		if(temp) {
			pw.write("<script>alert('您有书籍存在罚款，请您先提交罚款');window.location.href='checkbook.jsp'</script>");
		}		
		else{ 	
			Book_Dao book_dao=new Book_Dao();
			int book_sum=book_dao.SelectBookSum(book_id);
			System.out.println("book_sum:"+book_sum);
			//判断书籍数量大于0
			if(book_sum>0) {
				boolean temp1=book_service.LentBookSevice(reader_id, book_id);
				if(temp1) {
					System.out.println("借书信息插入成功");
					//借书成功后，更新书籍数量
					Book_Service book_service2=new Book_Service();
					boolean tem=book_service2.ShowLentBook(book_id);
					if(tem) {
						System.out.println("书籍数量更新成功");
						//查询lent_id,lent_time						
						ArrayList<Lent_information> list_lent=new ArrayList<Lent_information>();
						list_lent =book_dao.Select_LentIdAndLentTime(book_id);
						int lent_id=0;
						Date lent_time=null;
						System.out.println("list_lent:"+list_lent);
						
						for(Lent_information lent_information : list_lent) {

							lent_time=(Date) lent_information.getLent_time();
							lent_id=lent_information.getLent_id();
							
						}
						
						System.out.println("lent_id:"+lent_id);
						System.out.println("lent_time:"+lent_time);
						//将reader_id,bookid,lent_id插入history表
						Book_Service book_service3=new Book_Service();
						boolean tem2=book_service3.InsertHistory(reader_id,book_id,lent_id,lent_time);
						//将reader_id,bookid,lent_id插入fine表
						boolean tem3=book_service3.InsertFine(reader_id,book_id,lent_time);
						if(tem2&&tem3) {
								System.out.println("history和fine插入成功");
								System.out.println("借书成功");
								pw.write("<script>alert('借书成功');window.location.href='checkbook.jsp'</script>");
							}else {
								System.out.println("history和fine插入失败");
							}
						}
					
					else {
							System.out.println("书籍数量更新成功");
						}
						
						
					}else {
						System.out.println("借书失败");
						pw.write("<script>alert('借书失败，你已借过该书籍');window.location.href='checkbook.jsp'</script>");
					}
			}else {
				pw.write("<script>alert('借书失败，书籍数量不足');window.location.href='checkbook.jsp'</script>");
			}
			
			}
			
						
			
		
	}
       
 

}
