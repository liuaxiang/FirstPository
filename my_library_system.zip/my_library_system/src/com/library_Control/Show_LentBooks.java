package com.library_Control;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.library_Services.Book_Service;
import com.library_entity.Book;
import com.library_entity.Reader;

/**
 * Servlet implementation class Show_LentBooks
 */
@WebServlet("/Show_LentBooks")
public class Show_LentBooks extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");
		//从session中获取reader_id
		HttpSession session=req.getSession();
		Reader reader=(Reader) session.getAttribute("reader");
		int reader_id=reader.getReader_id();
		System.out.println("reader_id:"+reader_id);	
		//返回借书信息
		Book_Service book_service=new Book_Service();
		ArrayList<Book> lent_books=new ArrayList<> ();
		lent_books=book_service.ShowLentBooks(reader_id);	
		//把借书信息送往前端
		req.setAttribute("lent_books",  lent_books);
		req.getRequestDispatcher("lentbook.jsp").forward(req, resp);		
	}
   

}
