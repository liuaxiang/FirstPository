package com.library_Control;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library_Services.Reader_Service;
import com.library_entity.Category;
import com.library_entity.Lent_information;
import com.library_entity.Reader;
import com.library_entity.Return_time;

/**
 * Servlet implementation class ReaderRegister
 */
@WebServlet("/ReaderRegister")
public class ReaderRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		//获取注册页面信息
		String reader_name=request.getParameter("reader_name");
		String password=request.getParameter("password");
		String email=request.getParameter("email");
		String phone=request.getParameter("phone");
		String identity=request.getParameter("identity");
		
		//将信息上传数据库
		Reader reader=new Reader(null,reader_name,password,phone,null,identity,email);
		System.out.println("reader:"+reader);
		Reader_Service reader_service=new Reader_Service();
		boolean temp=reader_service.RegisterSevice(reader);

		response.setContentType("text/html;charset=utf-8");
		PrintWriter pw=response.getWriter();
		if(temp){
			System.out.println("注册成功");
			pw.write("<script>alert('注册成功');window.location.href='login.jsp'</script>");
		}else {
			System.out.println("注册失败");
			pw.write("<script>alert('注册失败');window.location.href='registration.jsp'</script>");
		}
	}
 

}
