package com.library_Control;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library_Services.Admin_Services;

/**
 * Servlet implementation class Delete_Book
 */
@WebServlet("/Delete_Book")
public class Delete_Book extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		//获取book_id
		int book_id = Integer.parseInt(request.getParameter("book_id"));
		System.out.println("book_id:"+book_id);
		Admin_Services admin_services=new Admin_Services();
		boolean temp=admin_services.DeleteBook(book_id);
		response.setContentType("text/html;charset=utf-8");
		PrintWriter pw=response.getWriter();
		if(temp) {
			System.out.println("书籍信息删除成功");
			pw.write("<script>alert('书籍信息删除成功');window.location.href='edit.jsp'</script>");
		}else {
			System.out.println("书籍信息删除失败");
			pw.write("<script>alert('书籍信息删除失败');window.location.href='edit.jsp'</script>");
		}
	}
       
 
}
