package com.library_Control;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library_Services.Book_Service;
import com.library_entity.Book;

/**
 * Servlet implementation class Show_Record
 */
@WebServlet("/Show_Record")
public class Show_Record extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		Book_Service book_service4=new Book_Service();
		ArrayList<Book> AL2=new ArrayList<> ();
		AL2=book_service4.ShowRecord();
		//把历史记录信息送往前端
		request.setAttribute("AL2",  AL2);
		request.getRequestDispatcher("record.jsp").forward(request, response);

	}
  
}
