package com.library_Control;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library_Services.Admin_Services;
import com.library_entity.Book;
import com.library_entity.Lent_information;

/**
 * Servlet implementation class Show_UpdateBook
 */
@WebServlet("/Show_UpdateBook")
public class Show_UpdateBook extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		//获取book_id
		int book_id = Integer.parseInt(request.getParameter("book_id"));
		System.out.println("book_id:"+book_id);
		Admin_Services admin_services =new Admin_Services();
		ArrayList<Book> book=new ArrayList<> ();
		book=admin_services.ShowBook(book_id);
		int book_id2=0;
		String book_name=null;
		String book_writer=null;
		int book_sum=0;
		String book_location=null;
		Date public_time=null;
		Date collection_time=null;
		for(Book book2 : book) {

			book_id2=book2.getBook_id();
			book_name=book2.getBook_name();
			book_writer=book2.getBook_writer();
			book_sum=book2.getBook_sum();
			book_location=book2.getLocation();
			public_time=(Date) book2.getPublic_date();
			collection_time=(Date) book2.getCollection_date();	
		}
		
		
		
		//把书籍信息送往前端
		request.setAttribute("book_id2",  book_id2);
	    request.setAttribute("book_name", book_name);
	    request.setAttribute( "book_writer", book_writer);
	    request.setAttribute( "book_sum", book_sum);
	    request.setAttribute( "book_location", book_location);
	    request.setAttribute("public_time", public_time);
	    request.setAttribute("collection_time", collection_time);	  
		request.getRequestDispatcher("modify.jsp").forward(request, response);
	}
       

}
