package com.library_Control;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.library_Services.Book_Service;
import com.library_entity.Fin_informattion;
import com.library_entity.Reader;

/**
 * Servlet implementation class Submit_Fine
 */
@WebServlet("/Submit_Fine")
public class Submit_Fine extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");
		//前端获取fine_id
		int fine_id = Integer.parseInt(req.getParameter("fine_id"));
		System.out.println("fine_id:"+fine_id);	
		//根据fine_id删除罚款信息
		Book_Service book_service=new Book_Service();
		boolean temp=book_service.DeleteFine(fine_id);
		resp.setContentType("text/html;charset=utf-8");
		PrintWriter pw=resp.getWriter();
		if(temp) {
			System.out.println("提交罚款成功");	
			pw.write("<script>alert('提交罚款成功');window.location.href='fine.jsp'</script>");
			
			//从session中获取reader_id
			HttpSession session=req.getSession();
			Reader reader=(Reader) session.getAttribute("reader");
			int reader_id=reader.getReader_id();	
			//刷新罚款信息
			ArrayList<Fin_informattion> Fin_informattion2=new ArrayList<>();
			Fin_informattion2=book_service.ShowFine(reader_id);
			req.setAttribute("Fin_informattion",  Fin_informattion2);
			req.getRequestDispatcher("fine.jsp").forward(req, resp);
			System.out.println("提交罚款成功");		
		}
		else {
			System.out.println("提交罚款失败");
		}
		
		
	}
   
}
