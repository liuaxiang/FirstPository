package com.library_Control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library_Services.Admin_Services;
import com.library_entity.Book;

/**
 * Servlet implementation class Update_Book
 */
@WebServlet("/Update_Book")
public class Update_Book extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		//获取注册页面信息

		int book_id = Integer.parseInt(request.getParameter("book_id"));
		String book_name=request.getParameter("book_name1");
		String book_writer=request.getParameter("book_writer1");
		int category_id=Integer.parseInt(request.getParameter("category_id"));
		int book_sum=Integer.parseInt(request.getParameter("book_sum1"));
		String location=request.getParameter("location1");
		String public_time1=request.getParameter("public_time1");
		String collection_time1=request.getParameter("collection_time1");
		//将util.Date转sql.Date
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");  
		java.util.Date date,date2;
		try {
			date = sdf.parse(public_time1);
			date2=sdf.parse(collection_time1);
			Date public_time = new java.sql.Date(date.getTime());
			Date collection_time = new java.sql.Date(date2.getTime());
			System.out.println("book_id:"+book_id);
			System.out.println("book_name:"+book_name);
			System.out.println("book_writer:"+book_writer);
			System.out.println("category_id:"+category_id);
			System.out.println("book_sum:"+book_sum);
			System.out.println("location:"+location);
			System.out.println("public_time:"+public_time);
			System.out.println("public_time:"+collection_time);
			//将信息上传数据库
			Book book=new Book(book_id,book_name,book_writer,category_id,book_sum,public_time,collection_time,location,null,null,null);
			System.out.println("添加书籍book:"+book);
			Admin_Services admin_services=new Admin_Services();
			boolean temp=admin_services.UpdateBooksSevice(book);
			
			response.setContentType("text/html;charset=utf-8");
			PrintWriter pw=response.getWriter();
			if(temp){
				System.out.println("书籍信息修改成功");
				pw.write("<script>alert('书籍信息修改成功');window.location.href='edit.jsp'</script>");
			}else {
				System.out.println("书籍信息修改失败");
				pw.write("<script>alert('书籍信息修改失败');window.location.href='edit.jsp'</script>");
			}
		
		} catch (ParseException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} 
	}
       
  

}
