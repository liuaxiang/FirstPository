package com.library_Control;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library_Services.Book_Service;
import com.library_entity.Book;

/**
 * Servlet implementation class Check_Books
 */
@WebServlet("/Check_Books")
public class Check_Books extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String book_name=request.getParameter("book_name");
		System.out.println("book_name:"+book_name);
		
//		response.setContentType("text/html;charset=utf-8");
//		PrintWriter pw=null;
//		pw = response.getWriter();
		//查询书籍
		Book_Service book_service=new Book_Service();
		ArrayList<Book> AL=new ArrayList<> ();
		AL=book_service.SelectBookssByUbook_name(book_name);
		//把书籍信息送往前端
		request.setAttribute("AL",  AL);
		request.getRequestDispatcher("checkbook.jsp").forward(request, response);
		
	}
       


}
