package com.library_Control;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.library_Services.Admin_Services;
import com.library_Services.Reader_Service;
import com.library_entity.Admin;
import com.library_entity.Reader;

/**
 * Servlet implementation class User_Login
 */
@WebServlet("/User_Login")
public class User_Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String username=request.getParameter("username");
		String password= request.getParameter("password");
		String usertype= request.getParameter("usertype");
		String Reader="Reader";
		System.out.println("usertype:"+usertype);
		System.out.println("username:"+username);
		System.out.println("password:"+password);
		response.setContentType("text/html;charset=utf-8");
		PrintWriter pw=null;
		pw = response.getWriter();
		if(username==null||"".equals(username)) {			
			pw.write("<script>alert('姓名为空');window.location.href='login.jsp'</script>");
			return;
		}else if(password==null||"".equals(password)) {
			pw.write("<script>alert('密码为空');window.location.href='login.jsp'</script>");
			//密码为空的时候方法结束  不再执行if语句下面的代码
			return;
		}else {
			//判断登录类型
			if(usertype.equals(Reader)) {
				Reader_Service reader_service =new Reader_Service();				
				Reader reader=reader_service.ReaderLogin(username.trim(), password.trim());
				if(reader!=null) {
					//把reader放入session
					HttpSession session = request.getSession();
					session.setAttribute("reader", reader);					
					request.getRequestDispatcher("index.jsp").forward(request, response);
					System.out.println("读者登录成功");
					pw.write("<script>alert('读者登录成功');window.location.href='index.jsp'</script>");
				}else {
					System.out.println("读者登录失败");
					pw.write("<script>alert('姓名或者密码错误');window.location.href='login.jsp'</script>");
				}
				
			}else {
				//管理员登录
				Admin_Services admin_service =new Admin_Services();
				Admin admin=admin_service.AdminLogin(username, password);
				if(admin!=null) {

					System.out.println("管理员登录成功");
//					req.getRequestDispatcher("administrator.jsp").forward(request, response);
					pw.write("<script>alert('管理员登录成功');window.location.href='admin.jsp'</script>");
				}else {
					System.out.println("管理员登录失败");
					pw.write("<script>alert('姓名或者密码错误');window.location.href='login.jsp'</script>");
				}
				
			}
			
		}
	}
		

}
