package com.library_Control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.library_Services.Book_Service;
import com.library_entity.Fin_informattion;
import com.library_entity.Lent_information;
import com.library_entity.Reader;

/**
 * Servlet implementation class Show_Fine
 */
@WebServlet("/Show_Fine")
public class Show_Fine extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final boolean ture = false;

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		HttpSession session=request.getSession();
		Reader reader=(Reader) session.getAttribute("reader");
		//获取借书时间
		int reader_id=reader.getReader_id();
		Book_Service book_service=new Book_Service();
		ArrayList<Fin_informattion> lent_time=book_service.Select_OverTime(reader_id);
	    System.out.println("over_time:"+lent_time);
	    Date lent_time2=null;
	    int fine_id=0;
		for(Fin_informattion Fin_informattion : lent_time) {

			
			lent_time2=Fin_informattion.getLent_time();	
			fine_id=Fin_informattion.getFine_id();
			//获取当前系统时间 
			SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd");
			Date now_date = new Date(System.currentTimeMillis());
			System.out.println("now_date:"+formatter.format(now_date)); //当前系统时间-借书时间
			long over_day=0;
			over_day=(now_date.getTime()-lent_time2.getTime())/(24*60*60*1000);
			System.out.println("over_day:"+over_day);
			 
			//逾期时间超过90天将产生罚款
			response.setContentType("text/html;charset=utf-8");
			PrintWriter pw=response.getWriter();
			if(over_day>90) {
				double fine=0;
				fine=(over_day-90)*0.2;
				boolean tem=book_service.InsertIntoFine(over_day, (float) fine, fine_id);
			}
		}
				
				
					//显示罚款信息
					ArrayList<Fin_informattion> Fin_informattion2=new ArrayList<>();
					Fin_informattion2=book_service.ShowFine(reader_id);
					request.setAttribute("Fin_informattion",  Fin_informattion2);
					request.getRequestDispatcher("fine.jsp").forward(request, response);
				
				
			
//			else {
//				pw.write("<script>alert('您没有相关罚款信息');window.location.href='fine.jsp'</script>");
//				System.out.println("罚款信息插入失败");
//			}
			
			
		
		

	
		
		
	}

}
