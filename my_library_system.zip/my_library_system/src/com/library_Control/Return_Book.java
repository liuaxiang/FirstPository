package com.library_Control;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.library_Dao.Book_Dao;
import com.library_Services.Book_Service;
import com.library_entity.Reader;

/**
 * Servlet implementation class Return_Book
 */
@WebServlet("/Return_Book")
public class Return_Book extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");
		int book_id = Integer.parseInt(req.getParameter("BookId"));
		System.out.println("BookId:"+book_id);
		
		//查询是否存在罚款
		Book_Service book_service=new Book_Service();		
		boolean tem=book_service.SelectFine();
		resp.setContentType("text/html;charset=utf-8");
		PrintWriter pw=resp.getWriter();
		if(tem) {
			pw.write("<script>alert('您有书籍存在罚款，请您先提交罚款');window.location.href='checkbook.jsp'</script>");
		}else {
			//还书信息插入
			boolean temp=book_service.ReturnBook(book_id);			
			if(temp) {
				System.out.println("还书成功");
				pw.write("<script>alert('还书成功');window.location.href='checkbook.jsp'</script>");
				//还书成功后，更新书籍数量
				Book_Service book_service4=new Book_Service();
				boolean tem2=book_service4.UpadeBookSum(book_id);
				if(tem2) {
					System.out.println("书籍数量加一");
					//在history表中插入书籍归还时间
					Book_Service book_service5=new Book_Service();
					boolean temp5=book_service5.InsrtReturnTime(book_id);
					if(temp5) {
						System.out.println("还书时间插入成功");
						//删除相关罚款信息
						//从session中获取reader_id
						HttpSession session=req.getSession();
						Reader reader=(Reader) session.getAttribute("reader");
						int reader_id=reader.getReader_id();		
						boolean temp6=book_service.DeleteFineByReader_idAndBook_id(reader_id, book_id);
						if(temp6) {
							System.out.println("多余罚款信息删除成功");
						}else {
							System.out.println("多余罚款信息删除失败");
						}
					}else {
						System.out.println("还书时间插入失败");
					}
					
				}else {
					System.out.println("书籍数量加一失败");
				}
			}else {
				System.out.println("还书失败");
				pw.write("<script>alert('还书失败,未借阅此书');window.location.href='checkbook.jsp'</script>");
			}
		}
	}
       


}
