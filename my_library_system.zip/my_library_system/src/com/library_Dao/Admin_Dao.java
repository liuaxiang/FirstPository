package com.library_Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.DBUtil.DBUtil;
import com.library_entity.Admin;
import com.library_entity.Book;
import com.library_entity.Category;

public class Admin_Dao implements Admin_DaoInfo{
	private static Connection conn=null;
	private static PreparedStatement stat=null;
	private static ResultSet rs=null;
	//根据管理员adminname，和password查询信息
	private final static String queryAdminByAdminNamePassword="select admin_name,admin_id from M_ADMIN t where admin_name=? and admin_password=?";
	//添加书籍
	private final static String AddBooks="insert into M_BOOK values(SEQ_BOOK.nextval,?,?,?,?,?,?,?)";
	//修改书籍信息
	private final static String UpdateBook="update M_BOOK set book_name=?,book_writer=?,category_id=?,book_sum=?,\r\n" + 
			"public_date=?,collection_date=?,location=? where book_id=?";
	//显示所修改书的信息
	private final static String ShowBookByBook_id="select * from M_BOOK where book_id=?";
	//删除书籍
	private final static String DeleteBook="delete from M_BOOK where book_id=?";
	
	//根据管理员adminname，和password查询信息	
	@Override
	public Admin queryAdminByAdminNamePassword(String Admin, String password) {
		Admin admin= null;
		conn=com.DBUtil.DBUtil.getConnection();
		try {
			stat=conn.prepareStatement(queryAdminByAdminNamePassword);
			stat.setString(1, Admin);
			stat.setString(2, password);
			rs=stat.executeQuery();
			if(rs.next()) {
				admin =new Admin();
				admin.setAdmin_id(rs.getInt("admin_id"));
				admin.setAdmin_name(rs.getString("admin_name"));
				System.out.println(admin);							
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return admin;
	}
	//添加书籍
	@Override
	public int AddBook(Book u) {
		conn=com.DBUtil.DBUtil.getConnection();
		int row=0;
		try {
			stat=conn.prepareStatement(AddBooks);
			stat.setString(1,u.getBook_name());
			stat.setString(2, u.getBook_writer());
			stat.setInt(3, u.getCategory_id());
			stat.setInt(4,u.getBook_sum());
			stat.setDate(5, (Date) u.getPublic_date());
			stat.setDate(6, (Date) u.getCollection_date());
			stat.setString(7, u.getLocation());	
			
		    row=stat.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return row;
	}
	//修改书籍信息
	@Override
	public int UpdateBook(Book book) {
		conn=com.DBUtil.DBUtil.getConnection();
		int row=0;
		try {
			stat=conn.prepareStatement(UpdateBook);
			stat.setString(1,book.getBook_name());
			stat.setString(2, book.getBook_writer());
			stat.setInt(3, book.getCategory_id());
			stat.setInt(4,book.getBook_sum());
			stat.setDate(5, (Date) book.getPublic_date());
			stat.setDate(6, (Date) book.getCollection_date());
			stat.setString(7, book.getLocation());	
			stat.setInt(8,book.getBook_id());
		    row=stat.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return row;
	}
	//显示所修改书的信息
	@Override
	public ArrayList<Book> ShowBook(int book_id) {
		ArrayList<Book>  list=new ArrayList();
		Book book= null;
		conn=com.DBUtil.DBUtil.getConnection();
		try {
			stat=conn.prepareStatement(ShowBookByBook_id);
			stat.setInt(1,book_id);	
			rs=stat.executeQuery();
			while(rs.next()) {
				book=new Book();
				
				book.setBook_id(rs.getInt("book_id"));
				book.setBook_name(rs.getString("book_name"));
				book.setBook_writer(rs.getString("book_writer"));
				book.setBook_sum(rs.getInt("book_sum"));
				book.setPublic_date(rs.getDate("public_date"));
				book.setCollection_date(rs.getDate("collection_date"));
				book.setLocation(rs.getString("location"));
				
				list.add(book);	
				System.out.println("list:"+ list);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return list;
	}
	//删除书籍
	@Override
	public int DeleteBook(int book_id) {
		conn=com.DBUtil.DBUtil.getConnection();
		int row=0;
		try {
			stat=conn.prepareStatement(DeleteBook);
			stat.setInt(1,book_id);			
		    row=stat.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return row;
	}
	

}
