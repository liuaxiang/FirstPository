package com.library_Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.xml.crypto.Data;
import com.DBUtil.DBUtil;
import com.library_entity.Book;
import com.library_entity.Category;
import com.library_entity.Fin_informattion;
import com.library_entity.History;
import com.library_entity.Lent_information;
import com.library_entity.Reader;
public class Book_Dao<BOOK> implements Book_DaoInfo{
	private static Connection conn=null;
	private static PreparedStatement stat=null;
	private static ResultSet rs=null;
	//根据书名模糊查找书籍
	private final static String Select_Books_By_BookName="select * from M_BOOK b,M_CATEGORY c where b.category_id=c.category_id "
			+ "and book_name like ? order by book_id desc";
	//根据reader_id查询借书信息
	private final static String Select_LentBook_By_ReaderId="select * from M_RETURN_TIME where reader_id=?";
	//借书后，图书数量减一
	private final static String Update_BookSum="update M_BOOK set book_sum=(book_sum-1) where book_id=?";
	//查询借书信息
	private final static String SelectLentBooks="select b.book_id,book_writer,book_name,lent_time,lent_id from M_BOOK b,M_LENT_INFORMAION l \r\n" + 
			"where b.book_id=l.book_id and reader_id=?";
	//查询lent_id,lent_time
	private final static String SelectLent_id ="select lent_id,lent_time from M_LENT_INFORMAION l where l.book_id=?";
	
	//将reader_id,bookid,lent_id插入history表
	private final static String InserHistory="insert into M_HISTORY(history_id,book_id,reader_id,lent_id,lent_time)values(SEQ_HISTORY.nextval,?,?,?,?)";
	
	//将reader_id,bookid,lent_id插入fine表
	private final static String InserFine="insert into M_FINE(fine_id,book_id,reader_id,lent_time)values(SEQ_FINE.nextval,?,?,?)";
	//显示历史纪录信息
	private final static String ShowRecord="select b.book_id,book_name,lent_time from M_BOOK b,M_LENT_INFORMAION t\r\n" + 
			"where b.book_id=t.book_id";
	//还书
	private final static String ReturnBook="delete from M_LENT_INFORMAION where book_id=?";
	//还书后，图书数量加一
	private final static String AddBookSum="update M_BOOK set book_sum=(book_sum+1) where book_id=?";
	//还书后插入还书时间
	private final static String InsertReturnTime="update M_HISTORY set return_time=Sysdate where book_id=?";
	//查询历史借书记录
	private final static String SelectHistory="select b.book_id,b.book_name,r.reader_id,r.reader_name,h.return_time,h.lent_time from  \r\n" + 
			"      M_HISTORY h,M_BOOK b,M_READER r where h.book_id=b.book_id and\r\n" + 
			"       h.reader_id=r.reader_id and  \r\n" + 
			"      h.reader_id=? order by history_id desc";
	//根据reader_id查询fine表中over_time
	private final static String SelectOverTimeFromFine=" select trunc((SELECT (select sysdate from dual)-lent_time over_time\r\n" + 
			" FROM M_FINE WHERE reader_id=?)) over_time from dual";
	//根据reader_id查询fine表中lent_time
	private final static String SelectLentTimeFromFine="select lent_time,fine_id from M_FINE where reader_id=?";
	//将逾期时间、罚款信息插入fine表
	private final static String InserIntoFine="update M_FINE set over_days=?,fine=?,state='1' where fine_id=?";
	//显示罚款信息
	private final static String showFine="select f.book_id,book_name,over_days,fine_id,fine from M_BOOK b,M_FINE f where reader_id=? \r\n" + 
			"and b.BOOK_ID=f.book_id and fine>0";
	//查询是否存在罚款
	private final static String SelectFineFromFine="select fine from M_FINE where fine>0";
	//删除罚款信息
	private final static String DeleteFineByFine_id="delete from M_FINE where fine_id=?";
	//删除为满足条件的罚款信息
	private final static String DeleteFineByReader_idAndBook_id="delete from M_FINE where reader_id=? and book_id=?";
	//借书时取书本数量
	private final static String SelectBookSum="select book_sum from M_BOOK where book_id =?";
		public ArrayList<Book> SelectBoods(String book_name) {
		ArrayList<Book>  list=new ArrayList();
		Book book= null;
		conn=com.DBUtil.DBUtil.getConnection();
		try {
			stat=conn.prepareStatement(Select_Books_By_BookName);
			stat.setString(1, "%"+book_name+"%");	
			rs=stat.executeQuery();
			while(rs.next()) {			
				book=new Book();
				book.setBook_id(rs.getInt("book_id"));
				book.setBook_name(rs.getString("book_name"));
				book.setBook_writer(rs.getString("book_writer"));
				book.setBook_sum(rs.getInt("book_sum"));
				book.setPublic_date(rs.getDate("public_date"));
				book.setCollection_date(rs.getDate("collection_date"));
				book.setLocation(rs.getString("location"));				
				Category category=new Category();
				category.setCategory(rs.getString("category"));				
				book.setCategory(category);				
				list.add(book);	
				System.out.println("list:"+ list);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return list;
	}

	@Override
	public ArrayList<Lent_information> SelectBoods(int reader_id) {
		ArrayList<Lent_information>  list=new ArrayList();
		Lent_information lent_infortion= null;
		conn=com.DBUtil.DBUtil.getConnection();
		try {
			stat=conn.prepareStatement(Select_Books_By_BookName);
			stat.setInt(1, reader_id);	
			rs=stat.executeQuery();
			while(rs.next()) {
				lent_infortion=new Lent_information();
				
				lent_infortion.setBook_id(rs.getInt("book_id"));
				lent_infortion.setReader_id(rs.getInt("reader_id"));
				lent_infortion.setLent_time(rs.getDate("return_time"));
				list.add(lent_infortion);	
				System.out.println("lent_infortion:"+ lent_infortion);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return list;
	}

	@Override
	public int UpdateBookSum(int book_id) {
		conn=com.DBUtil.DBUtil.getConnection();
		int row=0;
		try {
			stat=conn.prepareStatement(Update_BookSum);
			stat.setInt(1,book_id);			
		    row=stat.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return row;
	}
//显示借书信息
	@Override
	public ArrayList<Book> ShowLentBoods(int reader_id) {
		ArrayList<Book>  list=new ArrayList();
		Book book= null;
		conn=com.DBUtil.DBUtil.getConnection();
		try {
			stat=conn.prepareStatement(SelectLentBooks);
			stat.setInt(1, reader_id);	
			rs=stat.executeQuery();
			while(rs.next()) {
				book=new Book();
				
				book.setBook_id(rs.getInt("book_id"));
				book.setBook_name(rs.getString("book_name"));
				book.setBook_writer(rs.getString("book_writer"));
				
				Lent_information lent_infortion=new Lent_information();				
				lent_infortion.setLent_time(rs.getDate("lent_time"));
				lent_infortion.setLent_id(rs.getInt("lent_id"));
				book.setLent_information(lent_infortion);
				list.add(book);	
				System.out.println("借书时：book:"+ book);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return list;
	}
	//查询lent_id,lent_time

	@Override
	public ArrayList<Lent_information> Select_LentIdAndLentTime(int book_id) {
		ArrayList<Lent_information>  list=new ArrayList();
		Lent_information lent_infortion= null;
		conn=com.DBUtil.DBUtil.getConnection();
		try {
			stat=conn.prepareStatement(SelectLent_id);	
			stat.setInt(1, book_id);
			rs=stat.executeQuery();
			while(rs.next()) {
				lent_infortion=new Lent_information();
				lent_infortion.setLent_id(rs.getInt("lent_id"));
				lent_infortion.setLent_time(rs.getDate("lent_time"));
				list.add(lent_infortion);	
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return list;
	}

	
	//将reader_id,bookid,lent_id插入history表
		@Override
		public int Insert_History(int reader_id, int book_id, int lent_id,Date lent_time) {
			conn=com.DBUtil.DBUtil.getConnection();
			int row=0;
			try {
				stat=conn.prepareStatement(InserHistory);
				stat.setInt(1,book_id);			
				stat.setInt(2,reader_id);			
				stat.setInt(3,lent_id);	
				stat.setDate(4,lent_time);	
				
			    row=stat.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				DBUtil.closeResource(conn, stat, rs);
			}
			
			return row;
		}
		
	//将reader_id,bookid,lent_id插入fine表
		@Override
		public int Insert_Fine(int reader_id, int book_id,Date lent_time) {
			conn=com.DBUtil.DBUtil.getConnection();
			int row=0;
			try {
				stat=conn.prepareStatement(InserFine);
				stat.setInt(1,book_id);			
				stat.setInt(2,reader_id);				
				stat.setDate(3,lent_time);	
				
			    row=stat.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				DBUtil.closeResource(conn, stat, rs);
			}
			
			return row;
		}
	//显示历史纪录信息

	@Override
	public ArrayList<Book> ShowRecord() {
		ArrayList<Book>  list=new ArrayList();
		Book book= null;
		conn=com.DBUtil.DBUtil.getConnection();
		try {
			stat=conn.prepareStatement(ShowRecord);
		
			rs=stat.executeQuery();
			while(rs.next()) {
				book=new Book();				
				book.setBook_id(rs.getInt("book_id"));
				book.setBook_name(rs.getString("book_name"));
				
				Lent_information lent_infortion=new Lent_information();				
				lent_infortion.setLent_time(rs.getDate("lent_time"));
				book.setLent_information(lent_infortion);
				list.add(book);	
				System.out.println("历史记录：book:"+ book);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return list;
	}
	
	
	
//还书
	@Override
	public int DelectLentBook(int book_id) {
		conn=com.DBUtil.DBUtil.getConnection();
		int row=0;
		try {
			stat=conn.prepareStatement(ReturnBook);
			stat.setInt(1,book_id);			
		    row=stat.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return row;
	}
	//借书后，图书数量加一
	@Override
	public int UpdateBookSum2(int book_id) {
		conn=com.DBUtil.DBUtil.getConnection();
		int row=0;
		try {
			stat=conn.prepareStatement(AddBookSum);
			stat.setInt(1,book_id);			
		    row=stat.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return row;
	}
	//还书后插入还书时间
	@Override
	public int InserReturnTime(int book_id) {
		conn=com.DBUtil.DBUtil.getConnection();
		int row=0;
		try {
			stat=conn.prepareStatement(InsertReturnTime);
			stat.setInt(1,book_id);
		    row=stat.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return row;
	}
	//查询历史借书记录
	@Override
	public ArrayList<History> SelectHistory(int reader_id) {
		ArrayList<History>  list=new ArrayList();
		History history= null;
		conn=com.DBUtil.DBUtil.getConnection();
		try {
			stat=conn.prepareStatement(SelectHistory);
			stat.setInt(1,reader_id);
			rs=stat.executeQuery();
			while(rs.next()) {
				
				history=new History();	
				history.setReturn_time(rs.getDate("return_time"));				
				
				Book book=new Book();
				book.setBook_id(rs.getInt("book_id"));
				book.setBook_name(rs.getString("book_name"));
				
				Reader reader=new Reader();	
				reader.setReader_id(rs.getInt("reader_id"));
				reader.setReader_name(rs.getString("reader_name"));
				
				history.setBook(book);
				history.setReader(reader);		
				history.setLent_time(rs.getDate("lent_time"));
				list.add(history);	
				
				System.out.println("list:"+ list);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return list;
	}
	//查询over_time
	@Override
	public  ArrayList<Fin_informattion> Select_OverTime(int reader_id) {
		ArrayList<Fin_informattion>  list=new ArrayList();
		Fin_informattion lent_time= null;
		conn=com.DBUtil.DBUtil.getConnection();
		try {
			stat=conn.prepareStatement(SelectLentTimeFromFine);
			stat.setInt(1,reader_id);
			rs=stat.executeQuery();
			while(rs.next()) {
				lent_time=new Fin_informattion();
				lent_time.setLent_time(rs.getDate("lent_time"));
				lent_time.setFine_id(rs.getInt("fine_id"));
				list.add(lent_time);					

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return list;
		
	}
	//将逾期时间、罚款信息插入fine表
	public int InserIntoFine(long over_day,float fine,int reader_id) {
		conn=com.DBUtil.DBUtil.getConnection();
		int row=0;
		try {
			stat=conn.prepareStatement(InserIntoFine);
			stat.setInt(1,(int) over_day);
			stat.setFloat(2,fine);
			stat.setInt(3,reader_id);
		    row=stat.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return row;
	}
	//显示罚款信息
	@Override
	public ArrayList<Fin_informattion> ShowFine(int reader_id) {
		ArrayList<Fin_informattion>  list=new ArrayList();
		Fin_informattion fin_informattion= null;
		conn=com.DBUtil.DBUtil.getConnection();
		try {
			stat=conn.prepareStatement(showFine);
			stat.setInt(1,reader_id);
			rs=stat.executeQuery();
			while(rs.next()) {
				
				fin_informattion=new Fin_informattion();
				fin_informattion.setFine_id(rs.getInt("fine_id"));
				fin_informattion.setBook_id(rs.getInt("book_id"));
				fin_informattion.setBook_name(rs.getString("book_name"));
				fin_informattion.setOver_days(rs.getInt("over_days"));
				fin_informattion.setFine(rs.getDouble("fine"));				
				list.add(fin_informattion);					
				System.out.println("fin_informattion:"+ list);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return list;
	}
	//查询是否存在罚款
	@Override
	public int SelectFine() {
		conn=com.DBUtil.DBUtil.getConnection();
		int row=0;
		try {
			stat=conn.prepareStatement(SelectFineFromFine);
		    row=stat.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return row;
	}
    //提交罚款后删除罚款信息
	@Override
	public int DeleteFine(int fine_id) {
		conn=com.DBUtil.DBUtil.getConnection();
		int row=0;
		try {
			stat=conn.prepareStatement(DeleteFineByFine_id);
			stat.setInt(1,fine_id);			
		    row=stat.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return row;
	}
	//还书后删除罚款信息
	@Override
	public int DeleteOtherFine(int reader_id, int book_id) {
		conn=com.DBUtil.DBUtil.getConnection();
		int row=0;
		try {
			stat=conn.prepareStatement(DeleteFineByReader_idAndBook_id);
			stat.setInt(1,reader_id);	
			stat.setInt(2,book_id);				
		    row=stat.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return row;
		
	}
	//查询book_sum
	@Override
	public int SelectBookSum(int book_id) {
		int book_sum=0;
		conn=com.DBUtil.DBUtil.getConnection();
		try {
			stat=conn.prepareStatement(SelectBookSum);
			stat.setInt(1,book_id);
			rs=stat.executeQuery();
			while(rs.next()) {				
				book_sum=rs.getInt("book_sum");	
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return book_sum;
	}
}
	
	

