package com.library_Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.DBUtil.DBUtil;
import com.library_entity.Reader;

public class Reader_Dao implements Reader_DaoInfo{
	private static Connection conn=null;
	private static PreparedStatement stat=null;
	private static ResultSet rs=null;
	//根据读者readername，和password查询信息
	private final static String queryUserByUserNamePassword="select reader_name,reader_id from m_reader where reader_name=? and password=?";
	//注册信息
	private final static String InsertReader="insert into M_READER values(seq_reader.nextval,?,?,Sysdate,?,?,? )";
	//借书信息插入
	private final static String InsertLentBook="insert into M_LENT_INFORMAION values(?,?,Sysdate,SEQ_LENT.nextval)";
	
	//读者登录
	@Override
	public Reader queryReaderByReaderNamePassword(String readername, String password) {
		Reader reader= null;
		conn=com.DBUtil.DBUtil.getConnection();
		try {
			stat=conn.prepareStatement(queryUserByUserNamePassword);
			stat.setString(1, readername);
			stat.setString(2, password);
			rs=stat.executeQuery();
			if(rs.next()) {
				reader =new Reader();
				reader.setReader_id(rs.getInt("reader_id"));
				reader.setReader_name(rs.getString("reader_name"));
				System.out.println(reader);							
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return reader;
	}
	//读者注册

	@Override
	public int AddReader(Reader reader) {
		conn=com.DBUtil.DBUtil.getConnection();
		int row=0;
		try {
			stat=conn.prepareStatement(InsertReader);
			stat.setString(1,reader.getReader_name());
			stat.setString(2, reader.getPhone());
			stat.setString(3, reader.getPassword());
			stat.setString(4, reader.getIdentity());
			stat.setString(5, reader.getE_mail());
		    row=stat.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return row;
	}
	//读者借书
	@Override
	public int InsertIntoLentBook(int reader_id, int book_id) {
		conn=com.DBUtil.DBUtil.getConnection();
		int row=0;
		try {
			stat=conn.prepareStatement(InsertLentBook);
			stat.setInt(1,reader_id);
			stat.setInt(2,book_id);
		    row=stat.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.closeResource(conn, stat, rs);
		}
		
		return row;
	}

	

}
