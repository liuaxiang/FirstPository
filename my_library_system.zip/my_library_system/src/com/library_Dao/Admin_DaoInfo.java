package com.library_Dao;

import java.util.ArrayList;

import com.library_entity.Admin;
import com.library_entity.Book;
import com.library_entity.Fin_informattion;
import com.library_entity.Reader;

public interface Admin_DaoInfo {
	//管理员登录核对
	Admin queryAdminByAdminNamePassword(String Admin,String password);
	//添加书籍
	int AddBook(Book u);
	//修改书籍信息
	int UpdateBook(Book book);
	//显示所修改书的信息
	public ArrayList<Book> ShowBook(int book_id);
	//删除书籍
	int DeleteBook(int book_id);
}
