package com.library_Dao;

import java.util.ArrayList;

import com.library_entity.Book;
import com.library_entity.Reader;

public interface Reader_DaoInfo {
	//读者登录核对
	Reader queryReaderByReaderNamePassword(String readername,String password);
	//读者注册
	int AddReader(Reader u);
	//读者借书
	int InsertIntoLentBook(int reader_id,int book_id);	
}
