package com.library_Dao;

import java.sql.Date;
import java.util.ArrayList;


import com.library_entity.Book;
import com.library_entity.Fin_informattion;
import com.library_entity.History;
import com.library_entity.Lent_information;

public interface Book_DaoInfo {
	//查询书籍
	public ArrayList<Book> SelectBoods(String book_name);
	//查询借书信息
	public ArrayList<Lent_information> SelectBoods(int reader_id);
	//借书后更新书籍数量（减一）
	int UpdateBookSum(int book_id);
	//显示借书信息
	public ArrayList<Book> ShowLentBoods(int reader_id);
	//查询lent_id,lent_ime
	public ArrayList<Lent_information> Select_LentIdAndLentTime(int book_id);
	//将reader_id,bookid,lent_id插入history表
	int Insert_History(int reader_id,int book_id,int lent_id,Date lent_time);
	//将reader_id,bookid,lent_id插入fine表
	int Insert_Fine(int reader_id,int book_id,Date lent_time);
	//显示历史纪录信息
	public ArrayList<Book> ShowRecord();
	//还书
	int DelectLentBook(int book_id);
	//借书后更新书籍数量（加一）
	int UpdateBookSum2(int book_id);
	//还书后插入还书时间
	int InserReturnTime(int book_id);
	//查询历史借书记录
	public ArrayList<History> SelectHistory(int reader_id);
	//查询lent_time
	public ArrayList<Fin_informattion> Select_OverTime(int reader_id);
	//将逾期时间、罚款信息插入fine表
	public int InserIntoFine(long over_day,float fine,int reader_id);
	//显示罚款信息
	public ArrayList<Fin_informattion> ShowFine(int reader_id);
	//查询是否存在罚款
	int SelectFine();
	//提交罚款
	int DeleteFine(int fine_id);
	//还书后删除罚款信息
	int DeleteOtherFine(int reader_id,int book_id);
	//查询book_sum
	public int SelectBookSum(int book_id);
}
