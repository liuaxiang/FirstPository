package com.library_entity;

import java.util.Date;

public class Lent_information {
	private Integer lent_id;
	private Integer reader_id;
	private Integer book_id;
	private Date lent_time;
	
	public Lent_information() {
		
	}

	public Lent_information(Integer lent_id, Integer reader_id, Integer book_id, Date lent_time) {
		super();
		this.lent_id = lent_id;
		this.reader_id = reader_id;
		this.book_id = book_id;
		this.lent_time = lent_time;
	}

	public Integer getLent_id() {
		return lent_id;
	}

	public void setLent_id(Integer lent_id) {
		this.lent_id = lent_id;
	}

	public Integer getReader_id() {
		return reader_id;
	}

	public void setReader_id(Integer reader_id) {
		this.reader_id = reader_id;
	}

	public Integer getBook_id() {
		return book_id;
	}

	public void setBook_id(Integer book_id) {
		this.book_id = book_id;
	}

	public Date getLent_time() {
		return lent_time;
	}

	public void setLent_time(Date lent_time) {
		this.lent_time = lent_time;
	}

	@Override
	public String toString() {
		return "Lent_information [lent_id=" + lent_id + ", reader_id=" + reader_id + ", book_id=" + book_id
				+ ", lent_time=" + lent_time + "]";
	}
	

	
}
