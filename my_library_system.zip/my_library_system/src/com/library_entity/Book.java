package com.library_entity;

import java.util.Date;

public class Book {
	private Integer book_id;
	private String book_name;
	private String book_writer;
	private Integer category_id;
	private Integer book_sum;
	private Date public_date;
	private Date collection_date;
	private String location;
	//一端实体放多端
	private Category category;
	private Lent_information lent_information;
	private Return_time return_time;
	
	public Book() {
		
	}

	public Book(Integer book_id, String book_name, String book_writer, Integer category_id, Integer book_sum,
			Date public_date, Date collection_date, String location, Category category,
			Lent_information lent_information, Return_time return_time) {
		super();
		this.book_id = book_id;
		this.book_name = book_name;
		this.book_writer = book_writer;
		this.category_id = category_id;
		this.book_sum = book_sum;
		this.public_date = public_date;
		this.collection_date = collection_date;
		this.location = location;
		this.category = category;
		this.lent_information = lent_information;
		this.return_time = return_time;
	}

	public Integer getBook_id() {
		return book_id;
	}

	public void setBook_id(Integer book_id) {
		this.book_id = book_id;
	}

	public String getBook_name() {
		return book_name;
	}

	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}

	public String getBook_writer() {
		return book_writer;
	}

	public void setBook_writer(String book_writer) {
		this.book_writer = book_writer;
	}

	public Integer getCategory_id() {
		return category_id;
	}

	public void setCategory_id(Integer category_id) {
		this.category_id = category_id;
	}

	public Integer getBook_sum() {
		return book_sum;
	}

	public void setBook_sum(Integer book_sum) {
		this.book_sum = book_sum;
	}

	public Date getPublic_date() {
		return public_date;
	}

	public void setPublic_date(Date public_date) {
		this.public_date = public_date;
	}

	public Date getCollection_date() {
		return collection_date;
	}

	public void setCollection_date(Date collection_date) {
		this.collection_date = collection_date;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Lent_information getLent_information() {
		return lent_information;
	}

	public void setLent_information(Lent_information lent_information) {
		this.lent_information = lent_information;
	}

	public Return_time getReturn_time() {
		return return_time;
	}

	public void setReturn_time(Return_time return_time) {
		this.return_time = return_time;
	}

	@Override
	public String toString() {
		return "Book [book_id=" + book_id + ", book_name=" + book_name + ", book_writer=" + book_writer
				+ ", category_id=" + category_id + ", book_sum=" + book_sum + ", public_date=" + public_date
				+ ", collection_date=" + collection_date + ", location=" + location + ", category=" + category
				+ ", lent_information=" + lent_information + ", return_time=" + return_time + "]";
	}
	
	
	
}