package com.library_entity;

import java.util.Date;

public class Reader {
	private Integer reader_id;
	private String reader_name;
	private String password;
	private String phone;
	private Date regidate;
	private String identity;
	private String e_mail;
	
	public Reader() {
		
	}

	public Reader(Integer reader_id, String reader_name, String password, String phone, Date regidate, String identity,
			String e_mail) {
		super();
		this.reader_id = reader_id;
		this.reader_name = reader_name;
		this.password = password;
		this.phone = phone;
		this.regidate = regidate;
		this.identity = identity;
		this.e_mail = e_mail;
	}

	public Integer getReader_id() {
		return reader_id;
	}

	public void setReader_id(Integer reader_id) {
		this.reader_id = reader_id;
	}

	public String getReader_name() {
		return reader_name;
	}

	public void setReader_name(String reader_name) {
		this.reader_name = reader_name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Date getRegidate() {
		return regidate;
	}

	public void setRegidate(Date regidate) {
		this.regidate = regidate;
	}

	public String getIdentity() {
		return identity;
	}

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public String getE_mail() {
		return e_mail;
	}

	public void setE_mail(String e_mail) {
		this.e_mail = e_mail;
	}

	@Override
	public String toString() {
		return "Reader [reader_id=" + reader_id + ", reader_name=" + reader_name + ", password=" + password + ", phone="
				+ phone + ", regidate=" + regidate + ", identity=" + identity + ", e_mail=" + e_mail + "]";
	}
	
	
}	