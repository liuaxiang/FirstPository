package com.library_entity;

import java.sql.Date;

public class Fin_informattion {
	private Integer fine_id;
	private Integer reader_id;
	private Integer book_id;
	private Date lent_time;
	private Integer over_days;
	private String book_name;	
	private Number fine;
	private char state;
	public Fin_informattion() {
		super();
		// TODO 自动生成的构造函数存根
	}
	public Fin_informattion(Integer fine_id, Integer reader_id, Integer book_id, Date lent_time, Integer over_days,
			String book_name, Number fine, char state) {
		super();
		this.fine_id = fine_id;
		this.reader_id = reader_id;
		this.book_id = book_id;
		this.lent_time = lent_time;
		this.over_days = over_days;
		this.book_name = book_name;
		this.fine = fine;
		this.state = state;
	}
	public Integer getFine_id() {
		return fine_id;
	}
	public void setFine_id(Integer fine_id) {
		this.fine_id = fine_id;
	}
	public Integer getReader_id() {
		return reader_id;
	}
	public void setReader_id(Integer reader_id) {
		this.reader_id = reader_id;
	}
	public Integer getBook_id() {
		return book_id;
	}
	public void setBook_id(Integer book_id) {
		this.book_id = book_id;
	}
	public Date getLent_time() {
		return lent_time;
	}
	public void setLent_time(Date lent_time) {
		this.lent_time = lent_time;
	}
	public Integer getOver_days() {
		return over_days;
	}
	public void setOver_days(Integer over_days) {
		this.over_days = over_days;
	}
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	public Number getFine() {
		return fine;
	}
	public void setFine(Number fine) {
		this.fine = fine;
	}
	public char getState() {
		return state;
	}
	public void setState(char state) {
		this.state = state;
	}
	@Override
	public String toString() {
		return "Fin_informattion [fine_id=" + fine_id + ", reader_id=" + reader_id + ", book_id=" + book_id
				+ ", lent_time=" + lent_time + ", over_days=" + over_days + ", book_name=" + book_name + ", fine="
				+ fine + ", state=" + state + "]";
	}
	
}	