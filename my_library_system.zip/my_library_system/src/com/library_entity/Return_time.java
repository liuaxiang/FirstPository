package com.library_entity;

import java.util.Date;

public class Return_time {
	private Integer reader_id;
	private Integer book_id;
	private Date return_time;
	public Return_time() {
		
	}
	public Return_time(Integer reader_id, Integer book_id, Date return_time) {
		super();
		this.reader_id = reader_id;
		this.book_id = book_id;
		this.return_time = return_time;
	}
	public Integer getReader_id() {
		return reader_id;
	}
	public void setReader_id(Integer reader_id) {
		this.reader_id = reader_id;
	}
	public Integer getBook_id() {
		return book_id;
	}
	public void setBook_id(Integer book_id) {
		this.book_id = book_id;
	}
	public Date getReturn_time() {
		return return_time;
	}
	public void setReturn_time(Date return_time) {
		this.return_time = return_time;
	}
	@Override
	public String toString() {
		return "Return_time [reader_id=" + reader_id + ", book_id=" + book_id + ", return_time=" + return_time + "]";
	}
	
	
}
