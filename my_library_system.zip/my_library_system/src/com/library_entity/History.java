package com.library_entity;

import java.util.Date;

public class History {
	private Integer history_id;
	private Integer book_id;
	private Integer reader_id;
	private Integer lent_id;	
	private Date return_time;
	private Date lent_time;
	//一端实体放多端
	private Book book;
	private Reader reader;
	public History() {
		super();
		// TODO 自动生成的构造函数存根
	}
	public History(Integer history_id, Integer book_id, Integer reader_id, Integer lent_id, Date return_time,
			Date lent_time, Book book, Reader reader) {
		super();
		this.history_id = history_id;
		this.book_id = book_id;
		this.reader_id = reader_id;
		this.lent_id = lent_id;
		this.return_time = return_time;
		this.lent_time = lent_time;
		this.book = book;
		this.reader = reader;
	}
	public Integer getHistory_id() {
		return history_id;
	}
	public void setHistory_id(Integer history_id) {
		this.history_id = history_id;
	}
	public Integer getBook_id() {
		return book_id;
	}
	public void setBook_id(Integer book_id) {
		this.book_id = book_id;
	}
	public Integer getReader_id() {
		return reader_id;
	}
	public void setReader_id(Integer reader_id) {
		this.reader_id = reader_id;
	}
	public Integer getLent_id() {
		return lent_id;
	}
	public void setLent_id(Integer lent_id) {
		this.lent_id = lent_id;
	}
	public Date getReturn_time() {
		return return_time;
	}
	public void setReturn_time(Date return_time) {
		this.return_time = return_time;
	}
	public Date getLent_time() {
		return lent_time;
	}
	public void setLent_time(Date lent_time) {
		this.lent_time = lent_time;
	}
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	public Reader getReader() {
		return reader;
	}
	public void setReader(Reader reader) {
		this.reader = reader;
	}
	@Override
	public String toString() {
		return "History [history_id=" + history_id + ", book_id=" + book_id + ", reader_id=" + reader_id + ", lent_id="
				+ lent_id + ", return_time=" + return_time + ", lent_time=" + lent_time + ", book=" + book + ", reader="
				+ reader + "]";
	}
	
	
}
